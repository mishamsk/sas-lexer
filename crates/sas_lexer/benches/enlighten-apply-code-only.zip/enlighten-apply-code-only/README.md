enlighten-apply
========================

Example code and materials that illustrate applications of SAS machine learning techniques.

See individual subdirectories for specific examples and instructions. 

Contributors include:
Funda Gunes, Patrick Hall, Christian Medins, Radhikha Myneni, Jorge Silva, Brett Wujek and Ruiwen Zhang
